import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Pokemon } from '../models/pokemon.model';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {
  private http = inject(HttpClient);
  private pokemonsSubject = new BehaviorSubject<Pokemon[]>([]);
  public pokemons$ = this.pokemonsSubject.asObservable();
  private loadingSubject = new BehaviorSubject<boolean>(true);
  public loading$ = this.loadingSubject.asObservable();

  constructor() {
    this.loadPokemons();
  }

  loadPokemons(): void {
    this.loadingSubject.next(true);
    this.http.get<any>('https://pokeapi.co/api/v2/pokemon?limit=151').subscribe({
      next: (res) => {
        const requests: Observable<any>[] = res.results.map((p: any) => this.http.get<any>(p.url));
        forkJoin<any[]>(requests).subscribe({
          next: (details: any[]) => {
            const formatted: Pokemon[] = details.map((d) => ({
              id: d.id,
              name: d.name,
              image: d.sprites.other?.['official-artwork']?.front_default || d.sprites.front_default,
              types: d.types.map((t: any) => t.type.name),
              height: d.height / 10,
              weight: d.weight / 10,
              stats: d.stats.map((s: any) => ({
                name: s.stat.name,
                value: s.base_stat
              })),
              weaknesses: []
            }));
            this.pokemonsSubject.next(formatted);
            this.loadingSubject.next(false);
          },
          error: (err) => {
            console.error(err);
            this.loadingSubject.next(false);
          }
        });
      },
      error: (err) => {
        console.error(err);
        this.loadingSubject.next(false);
      }
    });
  }

  getPokemonById(id: number): Observable<Pokemon | undefined> {
    const current = this.pokemonsSubject.value;
    const found = current.find((p) => p.id === id);
    if (found) {
      return of(found);
    }
    return this.http.get<any>(`https://pokeapi.co/api/v2/pokemon/${id}`).pipe(
      map((d) => ({
        id: d.id,
        name: d.name,
        image: d.sprites.other?.['official-artwork']?.front_default || d.sprites.front_default,
        types: d.types.map((t: any) => t.type.name),
        height: d.height / 10,
        weight: d.weight / 10,
        stats: d.stats.map((s: any) => ({
          name: s.stat.name,
          value: s.base_stat
        })),
        weaknesses: []
      })),
      catchError(() => of(undefined))
    );
  }
}