import { Component, inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavController } from '@ionic/angular'; 
import { PokemonService } from '../services/pokemon.service';
import { Pokemon } from '../models/pokemon.model';

import {
  IonHeader, IonToolbar, IonTitle, IonSearchbar, IonContent,
  IonGrid, IonRow, IonCol, IonCard, IonImg, IonCardHeader,
  IonCardTitle, IonCardContent
} from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader, IonToolbar, IonTitle, IonSearchbar, IonContent,
    IonGrid, IonRow, IonCol, IonCard, IonImg, IonCardHeader,
    IonCardTitle, IonCardContent
  ]
})
export class HomePage implements OnInit {
  private pokemonService = inject(PokemonService);
  private navCtrl = inject(NavController);
  private cdr = inject(ChangeDetectorRef); 

  pokemons: Pokemon[] = [];
  filteredPokemons: Pokemon[] = [];

  ngOnInit(): void {
    this.pokemonService.pokemons$.subscribe((data) => {
      this.pokemons = data;
      this.filteredPokemons = data;
      this.cdr.detectChanges(); 
    });
  }

  filterPokemons(event: any): void {
    const term = event.target.value?.trim().toLowerCase() || '';

    if (!term) {
      this.filteredPokemons = this.pokemons;
      return;
    }

    this.filteredPokemons = this.pokemons.filter((p) => {
      const matchesName = p.name.toLowerCase().includes(term);
      const matchesId = p.id.toString() === term || `#${p.id}`.includes(term);
      return matchesName || matchesId;
    });
  }

  goToDetail(id: number): void {
    //solucion con el enrutador de Ionic
    this.navCtrl.navigateForward(['/pokemon-detail', id]);
  }
}