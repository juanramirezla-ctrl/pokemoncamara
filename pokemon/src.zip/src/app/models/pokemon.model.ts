export interface PokemonStat {
  name: string;
  value: number;
}

export interface Pokemon {
  id: number;
  name: string;
  image: string;
  types: string[];
  weaknesses: string[];
  height: number;
  weight: number;
  stats: PokemonStat[];
  isCustom?: boolean; // Bandera para saber si lo creamos por CRUD
}